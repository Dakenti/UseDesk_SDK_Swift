//
//  PINAnimatedImageView+PINRemoteImage.h
//  Pods
//
//  Created by Garrett Moon on 4/19/18.
//

#import <PINRemoteImage/PINAnimatedImageView.h>
#import <PINRemoteImage/PINRemoteImageCategoryManager.h>

@interface PINAnimatedImageView (PINRemoteImage) <PINRemoteImageCategory>

@end
